<?php

$languageStrings = array(
        'Ringover' => 'Ringover',
        'LBL_WELCOME' => 'A very warm welcome to you'
);
